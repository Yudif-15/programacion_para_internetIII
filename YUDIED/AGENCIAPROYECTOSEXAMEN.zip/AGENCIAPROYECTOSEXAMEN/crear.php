<?php
require_once "config/db.php";


$sql = "SELECT * FROM clientes WHERE estado = 1";
$stmt = $conexion->prepare($sql);
$stmt->execute();
$clientes = $stmt->fetchAll(PDO::FETCH_ASSOC);

if ($_POST) {

    $titulo = trim($_POST['titulo']);
    $descripcion = trim($_POST['descripcion']);
    $id_cliente = $_POST['id_cliente'];
    $presupuesto = $_POST['presupuesto'];
    $fecha_entrega = $_POST['fecha_entrega'];

    if (empty($titulo) || empty($descripcion) || empty($id_cliente) || empty($presupuesto) || empty($fecha_entrega)) {
        die("Todos los campos son obligatorios");
    }

    if (!is_numeric($presupuesto)) {
        die("Presupuesto invalido");
    }

    if ($fecha_entrega <= date('Y-m-d')) {
        die("La fecha debe ser mayor a hoy");
    }

    $sql = "INSERT INTO proyectos (titulo, descripcion, id_cliente, presupuesto, fecha_entrega)
            VALUES (:titulo, :descripcion, :id_cliente, :presupuesto, :fecha_entrega)";

    $stmt = $conexion->prepare($sql);

    $stmt->bindParam(":titulo", $titulo);
    $stmt->bindParam(":descripcion", $descripcion);
    $stmt->bindParam(":id_cliente", $id_cliente);
    $stmt->bindParam(":presupuesto", $presupuesto);
    $stmt->bindParam(":fecha_entrega", $fecha_entrega);

    $stmt->execute();

    header("Location: index.php");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Crear Proyecto</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="container mt-4">

<h2>Nuevo Proyecto</h2>

<form method="POST">

<input name="titulo" class="form-control mb-2" placeholder="Titulo">

<textarea name="descripcion" class="form-control mb-2" placeholder="Descripción"></textarea>

<select name="id_cliente" class="form-control mb-2">
    <?php foreach($clientes as $c): ?>
        <option value="<?= $c['id'] ?>">
            <?= $c['nombre_empresa'] ?>
        </option>
    <?php endforeach; ?>
</select>

<input name="presupuesto" class="form-control mb-2" placeholder="Presupuesto">

<input type="date" name="fecha_entrega" class="form-control mb-2">

<button class="btn btn-success">Guardar</button>

</form>

</body>
</html>