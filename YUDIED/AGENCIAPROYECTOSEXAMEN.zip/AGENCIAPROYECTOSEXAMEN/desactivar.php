<?php
require_once "config/db.php";

$id = $_GET['id'];

$sql = "UPDATE proyectos SET estado_activo = 0 WHERE id = :id";
$stmt = $conexion->prepare($sql);
$stmt->bindParam(":id", $id);
$stmt->execute();

header("Location: index.php");
?>