-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         8.0.30 - MySQL Community Server - GPL
-- SO del servidor:              Win64
-- HeidiSQL Versión:             12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Volcando estructura de base de datos para agencia_proyectos
CREATE DATABASE IF NOT EXISTS `agencia_proyectos` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `agencia_proyectos`;

-- Volcando estructura para tabla agencia_proyectos.clientes
CREATE TABLE IF NOT EXISTS `clientes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre_empresa` varchar(150) NOT NULL,
  `correo_contacto` varchar(150) NOT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `estado` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Volcando datos para la tabla agencia_proyectos.clientes: ~3 rows (aproximadamente)
INSERT INTO `clientes` (`id`, `nombre_empresa`, `correo_contacto`, `telefono`, `estado`) VALUES
	(1, 'Empresa ABC', 'abc@gmail.com', '9999-1111', 1),
	(2, 'Tech Solutions', 'tech@gmail.com', '8888-2222', 1),
	(9, 'SDSI', 'sdsi@gmail.com', '9909-3181', 1);

-- Volcando estructura para tabla agencia_proyectos.proyectos
CREATE TABLE IF NOT EXISTS `proyectos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `titulo` varchar(150) NOT NULL,
  `descripcion` text NOT NULL,
  `id_cliente` int NOT NULL,
  `presupuesto` decimal(10,2) NOT NULL,
  `fecha_entrega` date NOT NULL,
  `estado_activo` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `id_cliente` (`id_cliente`),
  CONSTRAINT `proyectos_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Volcando datos para la tabla agencia_proyectos.proyectos: ~3 rows (aproximadamente)
INSERT INTO `proyectos` (`id`, `titulo`, `descripcion`, `id_cliente`, `presupuesto`, `fecha_entrega`, `estado_activo`) VALUES
	(6, 'CREAR SISTEMA POS', 'Sistema POS para supermercado', 2, 200000.00, '2026-07-31', 1),
	(7, 'CREAR SISTEMA HERO', 'Sistema de Facturación', 2, 200000.00, '2026-08-25', 1),
	(8, 'CREAR SISTEMA SLESA', 'Sistema para facturación supermercado', 9, 500000.00, '2026-10-02', 1);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
