<?php
require_once "config/db.php";


$id = $_GET['id'];

$sql = "SELECT * FROM proyectos WHERE id = :id";
$stmt = $conexion->prepare($sql);
$stmt->bindParam(":id", $id);
$stmt->execute();
$proyecto = $stmt->fetch(PDO::FETCH_ASSOC);

$sql2 = "SELECT * FROM clientes WHERE estado = 1";
$stmt2 = $conexion->prepare($sql2);
$stmt2->execute();
$clientes = $stmt2->fetchAll(PDO::FETCH_ASSOC);

if ($_POST) {

    $titulo = trim($_POST['titulo']);
    $descripcion = trim($_POST['descripcion']);
    $id_cliente = $_POST['id_cliente'];
    $presupuesto = $_POST['presupuesto'];
    $fecha_entrega = $_POST['fecha_entrega'];

    if (empty($titulo) || empty($descripcion) || empty($id_cliente) || empty($presupuesto) || empty($fecha_entrega)) {
        die("Campos vacíos no permitidos");
    }

    if (!is_numeric($presupuesto)) {
        die("Presupuesto inválido");
    }

    if ($fecha_entrega <= date('Y-m-d')) {
        die("La fecha debe ser mayor a hoy");
    }

    $sql = "UPDATE proyectos 
            SET titulo=:titulo,
                descripcion=:descripcion,
                id_cliente=:id_cliente,
                presupuesto=:presupuesto,
                fecha_entrega=:fecha_entrega
            WHERE id=:id";

    $stmt = $conexion->prepare($sql);

    $stmt->bindParam(":titulo", $titulo);
    $stmt->bindParam(":descripcion", $descripcion);
    $stmt->bindParam(":id_cliente", $id_cliente);
    $stmt->bindParam(":presupuesto", $presupuesto);
    $stmt->bindParam(":fecha_entrega", $fecha_entrega);
    $stmt->bindParam(":id", $id);

    $stmt->execute();

    header("Location: index.php");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Editar Proyecto</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="container mt-4">

<h2>Editar Proyecto</h2>

<form method="POST">

<input name="titulo" class="form-control mb-2"
value="<?= $proyecto['titulo'] ?>">

<textarea name="descripcion" class="form-control mb-2">
<?= $proyecto['descripcion'] ?>
</textarea>

<select name="id_cliente" class="form-control mb-2">
    <?php foreach($clientes as $c): ?>
        <option value="<?= $c['id'] ?>"
        <?= $c['id'] == $proyecto['id_cliente'] ? 'selected' : '' ?>>
            <?= $c['nombre_empresa'] ?>
        </option>
    <?php endforeach; ?>
</select>

<input name="presupuesto" class="form-control mb-2"
value="<?= $proyecto['presupuesto'] ?>">

<input type="date" name="fecha_entrega"
class="form-control mb-2"
value="<?= $proyecto['fecha_entrega'] ?>">

<button class="btn btn-success">Actualizar</button>

</form>

</body>
</html>