<?php
require_once "config/db.php";

$sql = "SELECT p.*, c.nombre_empresa 
        FROM proyectos p
        INNER JOIN clientes c ON p.id_cliente = c.id
        WHERE p.estado_activo = 1";

$stmt = $conexion->prepare($sql);
$stmt->execute();
$proyectos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Proyectos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="container mt-4">

<h2>Lista de Proyectos</h2>

<?php if(isset($_GET['ok'])): ?>
<div class="alert alert-success">✔ Guardado correctamente</div>
<?php endif; ?>

<a href="crear.php" class="btn btn-primary mb-3">Nuevo Proyecto</a>

<table class="table table-bordered">
    <thead>
        <tr>
            <th>Título</th>
            <th>Cliente</th>
            <th>Presupuesto</th>
            <th>Fecha entrega</th>
            <th>Acciones</th>
        </tr>
    </thead>

    <tbody>
        <?php foreach($proyectos as $p): ?>
        <tr>
            <td><?= $p['titulo'] ?></td>
            <td><?= $p['nombre_empresa'] ?></td>
            <td>L. <?= number_format($p['presupuesto'],2) ?></td>
            <td><?= $p['fecha_entrega'] ?></td>
            <td>
                <a href="editar.php?id=<?= $p['id'] ?>" class="btn btn-info btn-sm">Editar</a>
                <a href="desactivar.php?id=<?= $p['id'] ?>" class="btn btn-warning btn-sm">Soft</a>
                <a href="eliminar.php?id=<?= $p['id'] ?>" class="btn btn-danger btn-sm">Hard</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

</body>
</html>